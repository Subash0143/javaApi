package edu.LuffyApi.ImagesOfOnePeice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImagesOfOnePeiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
