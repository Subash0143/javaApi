package edu.LuffyApi.ImagesOfOnePeice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImagesOfOnePeiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImagesOfOnePeiceApplication.class, args);
	}

}
